//
//  AppDelegate.h
//  ShowLageImage
//
//  Created by 小点草 on 2018/3/2.
//  Copyright © 2018年 小点草. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

