//
//  main.m
//  ShowLageImage
//
//  Created by 小点草 on 2018/3/2.
//  Copyright © 2018年 小点草. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
